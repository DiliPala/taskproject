 
<?php if(count($body)>0): ?>
<div class="row">
<?php $__currentLoopData = $body; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-3  p-adjust mb-2">
      <div class="card">
         <div class="menu"><i class="fa fa-sort-amount-desc"></i></div>
         <div class="movie-img">
		 <?php if($b['poster_path'] !='' && $b['poster_path'] !=null): ?>
           <img class="imgalign" src="https://image.tmdb.org/t/p/w500/.<?php echo e(isset($b['poster_path'])?$b['poster_path']:''); ?>">
        <?php else: ?>
           <img class="" style="width:100%;" src="<?php echo e(url('img/dummy2.JPG')); ?>">
		<?php endif; ?>
		</div>
         <div class="text-movie-cont-1 card-body">
            <div class="mr-grid">
               <div class="col1">
                  <h6><?php echo e(isset($b['title'])?$b['title']:''); ?></h6>
                  <ul class="movie-gen">
				  <?php if(isset($b['geners']) && count($b['geners'])>0): ?>
				  <?php $__currentLoopData = $b['geners']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				  <?php if($loop->last): ?>
                     <li><?php echo e($gen); ?></li>
				  <?php else: ?>
                     <li><?php echo e($gen); ?>,</li>
				  <?php endif; ?>
					 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
				  <?php endif; ?>
               </div>
            </div>
            <div class="summary-row row">
              <div class="col-6">
                <span class="movie-time"><i class="fa fa-clock-o mr-1"></i> <?php echo e(isset($b['release_date'])?date_format(date_create($b['release_date']),"M d, Y"):''); ?></span>
              </div>
			   <div class="col-6">
                <span class="movie-time">Popularity: <?php echo e(isset($b['popularity'])?round($b['popularity'],0).'%':''); ?></span>
              </div>
            </div>
            <div class=" summary-row row">
               <div class="col2-1 col-6">
                  <h6>Summary</h6>
               </div>
               
            </div>
            <div class="mr-grid">
               <div class="col1"> 
                  <p class="movie-description"><?php echo e(isset($b['overview'])?substr($b['overview'],0,100 ):''); ?> 
                  </p>
               </div>
            </div>
           
         
         </div>
      </div>




      <!--  cards -->




 </div>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </div>
 <?php endif; ?>