        <div class="flex-center position-ref full-height">
           

            <div class="content">
                <div class="title m-b-md">
                    Welcome 
                </div>

                
            </div>
        </div>
    

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>