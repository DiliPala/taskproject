 
@if(count($body)>0)
<div class="row">
@foreach($body as $b)
<div class="col-3  p-adjust mb-2">
      <div class="card">
         <div class="menu"><i class="fa fa-sort-amount-desc"></i></div>
         <div class="movie-img">
		 @if($b['poster_path'] !='' && $b['poster_path'] !=null)
           <img class="imgalign" src="https://image.tmdb.org/t/p/w500/.{{isset($b['poster_path'])?$b['poster_path']:''}}">
        @else
           <img class="" style="width:100%;" src="{{url('img/dummy2.JPG')}}">
		@endif
		</div>
         <div class="text-movie-cont-1 card-body">
            <div class="mr-grid">
               <div class="col1">
                  <h6>{{isset($b['title'])?$b['title']:''}}</h6>
                  <ul class="movie-gen">
				  @if(isset($b['geners']) && count($b['geners'])>0)
				  @foreach($b['geners'] as $gen)
				  @if($loop->last)
                     <li>{{$gen}}</li>
				  @else
                     <li>{{$gen}},</li>
				  @endif
					 @endforeach
                  </ul>
				  @endif
               </div>
            </div>
            <div class="summary-row row">
              <div class="col-6">
                <span class="movie-time"><i class="fa fa-clock-o mr-1"></i> {{isset($b['release_date'])?date_format(date_create($b['release_date']),"M d, Y"):''}}</span>
              </div>
			   <div class="col-6">
                <span class="movie-time">Popularity: {{isset($b['popularity'])?round($b['popularity'],0).'%':''}}</span>
              </div>
            </div>
            <div class=" summary-row row">
               <div class="col2-1 col-6">
                  <h6>Summary</h6>
               </div>
               
            </div>
            <div class="mr-grid">
               <div class="col1"> 
                  <p class="movie-description">{{isset($b['overview'])?substr($b['overview'],0,100 ):''}} 
                  </p>
               </div>
            </div>
           
         
         </div>
      </div>




      <!--  cards -->




 </div>
 @endforeach
 </div>
 @endif