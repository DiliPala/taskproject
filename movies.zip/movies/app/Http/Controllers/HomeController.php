<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Client;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }
	public function blog(Request $request)
    {
	
	$page = $request->page;
	$text = $request->text;
		$client1 = new Client();
	$response1 = $client1->request('GET', 'https://api.themoviedb.org/3/genre/movie/list?api_key=342bbf8587b0c1eb26b97464ec02e1a4&language=en-US');
	$body1 = $response1->getBody()->getContents();
	$json_gener= json_decode($body1,true);
	// dd($dd1);
	$genersall = $json_gener['genres'];
	if($text!='' && $text!=null){
		
		$client = new Client();

	$response = $client->request('GET', 'https://api.themoviedb.org/3/search/movie?api_key=342bbf8587b0c1eb26b97464ec02e1a4&language=en-US&page='.$page.'&include_adult=false&query='.$text);
		}
		else{
	$client = new Client();

	$response = $client->request('GET', 'https://api.themoviedb.org/3/movie/top_rated?api_key=342bbf8587b0c1eb26b97464ec02e1a4&page='.$page);
		}
	$statusCode = $response->getStatusCode();
	$body = $response->getBody()->getContents();
	$toprated = json_decode($body,true);
$data2=$toprated['results'];

foreach($data2 as $in => $da){
	
	$geners = $da['genre_ids'];
	
	foreach($geners as $das){
	
	
	foreach($genersall as $gen){
		if($gen['id'] == $das){
			$data2[$in]['geners'][]=$gen['name'];
	// dd($data2[$in]);
			}
		}
		}
}

$data['body'] = $data2;
	// dd($data2);
        return view('moviecard',$data);
    }
	
	public function upcoming(Request $request)
    {
	
	$page = $request->page;
	$text = $request->text;
		$client1 = new Client();
	$response1 = $client1->request('GET', 'https://api.themoviedb.org/3/genre/movie/list?api_key=342bbf8587b0c1eb26b97464ec02e1a4&language=en-US');
	$body1 = $response1->getBody()->getContents();
	$json_gener= json_decode($body1,true);
	// dd($dd1);
	$genersall = $json_gener['genres'];
	if($text!='' && $text!=null){
		
		$client = new Client();

	$response = $client->request('GET', 'https://api.themoviedb.org/3/search/movie?api_key=342bbf8587b0c1eb26b97464ec02e1a4&language=en-US&page='.$page.'&include_adult=false&query='.$text);
		}
		else{
	$client = new Client();

	$response = $client->request('GET', 'https://api.themoviedb.org/3/movie/upcoming?api_key=342bbf8587b0c1eb26b97464ec02e1a4&page='.$page);
		}
	$statusCode = $response->getStatusCode();
	$body = $response->getBody()->getContents();
	$toprated = json_decode($body,true);
$data2=$toprated['results'];

foreach($data2 as $in => $da){
	
	$geners = $da['genre_ids'];
	
	foreach($geners as $das){
	
	
	foreach($genersall as $gen){
		if($gen['id'] == $das){
			$data2[$in]['geners'][]=$gen['name'];
	// dd($data2[$in]);
			}
		}
		}
}

$data['body'] = $data2;
	// dd($data2);
        return view('moviecard',$data);
    }
}
